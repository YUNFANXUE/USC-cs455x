// Name:
// USC NetID:
// CSCI455 PA2
// Fall 2018


/**
   <add main program comment here>
*/

public class BulgarianSolitaireSimulator {

   public static void main(String[] args) {
     
      boolean singleStep = false;
      boolean userConfig = false;

      for (int i = 0; i < args.length; i++) {
         if (args[i].equals("-u")) {
            userConfig = true;
         }
         else if (args[i].equals("-s")) {
            singleStep = true;
         }
      }

      // <add code here>
      
   }
   
   // <add private static methods here>

  
}
