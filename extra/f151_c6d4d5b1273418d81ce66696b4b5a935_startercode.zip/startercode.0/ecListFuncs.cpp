/*  Name:
 *  USC NetID:
 *  CS 455 Fall 2018
 *
 *  See ecListFuncs.h for specification of each function.
 *
 *  NOTE: remove the print statements below as you implement each function
 *  or you will receive no credit for that function.
 *
 */

#include <iostream>
#include <vector>

#include "ecListFuncs.h"

using namespace std;


ListType vectorToList(const vector<int> & nums) {

   cout << "*** WARNING: vectorToList has not been implemented yet. ***" << endl;
   return NULL;  // stub code to get it to compile
}



int countRuns(ListType list) {

   cout << "*** WARNING: countRuns has not been implemented yet. ***" << endl;
   return 0;  // stub code to get it to compile

}



ListType reverse(ListType list) {

   cout << "*** WARNING: reverse has not been implemented yet. ***" << endl;
   return NULL;  // stub code to get it to compile

}



void removeMiddle(ListType &list) {
   cout << "*** WARNING: removeMiddle has not been implemented yet. ***" << endl;
}



void split(ListType &list, int splitVal, ListType &a, ListType &b) {
   cout << "*** WARNING: split has not been implemented yet. ***" << endl;
}
